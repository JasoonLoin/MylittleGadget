﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankSystem
{
    class User
    {

        #region Attribute
        private string name_F;
        public string Name_F
        {
            get { return name_F; }
            set { name_F = value; }
        }
        private string name_L;
        public string Name_L
        {
            get { return name_L; }
            set { name_L = value; }
        }
        private string address;
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        private int number;
        public int Number
        {
            get { return number; }
            set { number = value; }
        }
        private string email;
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        private long account;
        public long Account
        {
            get { return account; }
            set { account = value; }
        }
        private int balance;
        public int Balance
        {
            get { return balance; }
            set { balance = value; }
        }

        #endregion
    }
}
