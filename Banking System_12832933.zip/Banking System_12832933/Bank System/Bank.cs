﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Net.Mail;


namespace BankSystem
{
    class Bank
    {
        private List<User> UserList = new List<User>();     // Create a list to contain all users.
        List<Login> loginList = new List<Login>();          // Create a list to contain all users account number and password.
        string tempBalance;
        string tempNumber;


        static string smtpAddress = "smtp.gmail.com";      // All required information for sending the email.
        static int portNumber = 587;
        static bool enableSSL = true;
        static string emailFromAddress = "";  // Privacy !!! I will show the email function in DEMO next week.
        static string password = "";   // Privacy !!! I will show the send email function in DEMO next week.
        static string emailToAddress = "";
        static string subject = "Banking Receipt";
        static string body = "The User Transaction is shown below";

        public List<Login> Initial()
        {

            string filePath = "login.txt";
            List<string> lines = File.ReadAllLines(filePath).ToList();    // Initial the information for login.txt file.
            foreach (var line in lines)
            {
                string[] entries = line.Split('|');
                Login login = new Login();

                login.acc = entries[0];        // Read the information in login.txt and assign them into variable acc and pwd.
                login.pwd = entries[1];
                loginList.Add(login);

            }
            return loginList;     // return the loginlist.
        }
        public void AccountDetail(string name_F, string name_L, string address, int number, string email, long account, int balance)
        {
            string filePath =  account + ".txt";
            using (StreamWriter sw = new StreamWriter(filePath))   // create a file based the account number
            {
                sw.WriteLine("First Name|{0}", name_F);     // file has all information based on what the user type
                sw.WriteLine("Last Name|{0}", name_L);
                sw.WriteLine("Address|{0}", address);
                sw.WriteLine("Phone|{0}", number);
                sw.WriteLine("Email|{0}", email);
                sw.WriteLine("Balance|{0}", balance);
            }
        }
        public void SaveAccount(long account)
        {
            try  //use try to test the SaveAccount function
            {
                string filePath =  account + ".txt";
                List<string> lines = File.ReadAllLines(filePath).ToList();

                User user = new User();
                user.Account = account;
                string[] line1 = lines[0].Split('|');     //Read the file in the account number.txt and put it into the userList on by on.
                user.Name_F = line1[1];
                string[] line2 = lines[1].Split('|');
                user.Name_L = line2[1];
                string[] line3 = lines[2].Split('|');
                user.Address = line3[1];
                string[] line4 = lines[3].Split('|');
                tempNumber = line4[1];
                string[] line5 = lines[4].Split('|');
                user.Email = line5[1];
                string[] line6 = lines[5].Split('|');
                tempBalance = line6[1];


                UserList.Add(user);
                
            }

            catch // ignore the error
            {
                
            }
        }
        public void ShowLoginMenu()
        {


            Console.Clear();
            Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t║         WELCOME TO THE SIMPLE BANKING SYSTEM        ║");
            Console.WriteLine("\t\t║═════════════════════════════════════════════════════║");
            Console.WriteLine("\t\t║                   LOGIN TO START                    ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║            Username:");
            int LoginCursorX = Console.CursorLeft;
            int LoginCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║            Password:");
            int PwdCursorX = Console.CursorLeft;
            int PwdCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
            int EnterCursorX = Console.CursorLeft;
            int EnterCursorY = Console.CursorTop;
            Console.SetCursorPosition(LoginCursorX, LoginCursorY); // Good design for Banking System
            string userInput = Console.ReadLine();
            Console.SetCursorPosition(PwdCursorX, PwdCursorY);
            string pwdInput = null;

            while (true)
            {
                ConsoleKeyInfo PwdInput = Console.ReadKey(true);
                if (PwdInput.Key != ConsoleKey.Enter)
                {

                    if (PwdInput.Key != ConsoleKey.Backspace)
                    {
                        pwdInput += PwdInput.KeyChar.ToString();    //make password invisible with *.
                        Console.Write("*");


                    }
                    else
                    {
                        if (pwdInput != null)
                        {
                            if (pwdInput.Length > 0)
                            {
                                pwdInput = pwdInput.Remove(pwdInput.Length - 1, 1);   //limit the length of password in case of bug.
                                Console.Write("\b \b");
                            }
                        }
                    }
                }
                else
                {
                    Console.WriteLine();
                    break;


                }
            }
            foreach (var person in Initial()) // Read all infomration from login.txt and see if the user input from key match with it.  
            {
                if (pwdInput != null && userInput.Equals(person.acc) && pwdInput.Equals(person.pwd))
                {
                    Console.SetCursorPosition(EnterCursorX, EnterCursorY);
                    Console.WriteLine("\t\t\tValid Credentials!... Please enter");
                    Console.ReadKey();
                    ShowCustomMenu();
                }

            }
            Console.SetCursorPosition(EnterCursorX, EnterCursorY);
            Console.WriteLine("\t\t\tInvalid Credentials!... Please enter again");
            Console.ReadKey();
            ShowLoginMenu();
        }
        public void ShowCustomMenu()
        {

            while (true)
            {

                Console.Clear();
                Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
                Console.WriteLine("\t\t║         WELCOME TO THE SIMPLE BANKING SYSTEM        ║");
                Console.WriteLine("\t\t║═════════════════════════════════════════════════════║");
                Console.WriteLine("\t\t║            1. Create a new account                  ║");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t║            2. Search for an account                 ║");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t║            3. Deposit                               ║");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t║            4. Withdraw                              ║");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t║            5. A/C statement                         ║");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t║            6. Delete account                        ║");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t║            7. Exit                                  ║");
                Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
                Console.Write("\t\t\t       Enter your choice(1-7):");
                string TempUserInput = Console.ReadLine();
                int userInput;
                if (int.TryParse(TempUserInput, out userInput)) // swtich to give seven choices for user
                {
                    switch (userInput)
                    {

                        case 1:
                            CreateAccount();
                            break;
                        case 2:
                            SearchAccount();
                            break;
                        case 3:
                            Deposit();
                            break;
                        case 4:
                            Withdraw();
                            break;
                        case 5:
                            AcStatment();
                            break;
                        case 6:
                            DeleteAccount();
                            break;
                        case 7:
                            Console.WriteLine("\t\t                                       ");
                            Console.WriteLine("\t\t\t   Thanks for using, see you again!!!");
                            Console.ReadKey();
                            System.Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("\t\t                                 ");
                            Console.WriteLine("\t\t\tInvalid number,Please try again");
                            Console.ReadKey();
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("\t\t                                 ");
                    Console.WriteLine("\t\t\tInvalid character,Please try again");
                    Console.ReadKey();
                    ShowCustomMenu();
                }
            }

        }
        public long Random() // A function to generate random number
        {
            Random generator = new Random();
            int randNum = generator.Next(100000, 101000);
            return randNum;

        }
        public void CreateAccount()
        {


            Console.Clear();
            Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t║                 CREATE A NEW ACCOUNT                ║");
            Console.WriteLine("\t\t║═════════════════════════════════════════════════════║");
            Console.WriteLine("\t\t║                   ENTER THE DETAILS                 ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           First Name:");
            int FNCursorX = Console.CursorLeft;
            int FNCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Last Name:");
            int LNCursorX = Console.CursorLeft;
            int LNCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Address:");
            int AddCursorX = Console.CursorLeft;
            int AddCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Phone:");
            int PCursorX = Console.CursorLeft;
            int PCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Email:");
            int ECursorX = Console.CursorLeft;
            int ECursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
            int TempCursorX = Console.CursorLeft;
            int TempCursorY = Console.CursorTop;
            int EnterCursorX = Console.CursorLeft;
            int EnterCursorY = Console.CursorTop;
            Console.SetCursorPosition(FNCursorX, FNCursorY);  // Good design for Banking System
            string FNInput = Console.ReadLine();
            Console.SetCursorPosition(LNCursorX, LNCursorY);
            string LNInput = Console.ReadLine();
            Console.SetCursorPosition(AddCursorX, AddCursorY);
            string AddInput = Console.ReadLine();
            Console.SetCursorPosition(PCursorX, PCursorY);
            string TempPInput = Console.ReadLine();
            int parsePInput;
            if (!int.TryParse(TempPInput, out parsePInput))  //test if it's a int
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t\t    Invalid Input,Please enter again.");
                Console.ReadKey();
                CreateAccount();
            }
            Console.SetCursorPosition(ECursorX, ECursorY);
            string EInput = Console.ReadLine();
            Console.SetCursorPosition(TempCursorX, TempCursorY);
            long rand = Random();
            Console.WriteLine("\t\t                                  ");
            Console.Write("\t\t    Is the information correct (y/n)?");
            string userInput = Console.ReadLine();
            var Lower = userInput?.ToLower();
            if (Lower == "y" && parsePInput.ToString().Length <= 10 && EInput.Contains("@")) //see if it meet all requirement
            {
                Console.WriteLine("\t\t                                                         ");
                Console.WriteLine("\t\t    Account Created! Details will be provided via email.");
                AccountDetail(FNInput, LNInput, AddInput, parsePInput, EInput, rand, 0); // Create a file based on what user type - like 100008.txt
                Console.WriteLine("\t\t                                        ");
                Console.WriteLine("\t\t    Account number is:{0}{1}", rand, ".");
                Console.ReadKey();
                ShowCustomMenu();
            }
            else if(Lower == "n")
            {
                CreateAccount();  // if press n, recall createAccount
            }
            else
            {
                Console.WriteLine("\t\t                                       ");
                Console.WriteLine("\t\t    Invalid Access,Please enter again.");
                Console.ReadKey();
                CreateAccount();

            }
        }
        public void SearchAccount()
        {
            Console.Clear();
            Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t║                 SEARCH AN ACCOUNT                   ║");
            Console.WriteLine("\t\t║═════════════════════════════════════════════════════║");
            Console.WriteLine("\t\t║                 ENTER THE DETAILS                   ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Account Number:");
            int AcCursorX = Console.CursorLeft;
            int AcCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
            int TempCursorX = Console.CursorLeft;
            int TempCursorY = Console.CursorTop;
            Console.SetCursorPosition(AcCursorX, AcCursorY);
            string TempAcInput = Console.ReadLine();
            long parseAcInput;
            if (!long.TryParse(TempAcInput, out parseAcInput) || parseAcInput.ToString().Length >10) // Account number should be no more than 10
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t                                 ");
                Console.WriteLine("\t\t\t    Please enter correct number");
                Console.ReadKey();
                SearchAccount();
            }
            SaveAccount(parseAcInput); // Read the information and put them all into userList
            User user = CheckUser(parseAcInput); // Check if a user is exist.
            if (user == null)
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t                                 ");
                Console.WriteLine("\t\t\t    Account not found");
                Console.WriteLine("\t\t                                 ");
                Console.Write("\t\t\t    Check another acount (y/n)?");
                string userInput = Console.ReadLine();
                var Lower = userInput?.ToLower(); //Check another another based on the key input
                if (Lower == "y")
                {
                    SearchAccount();
                }
                else if (Lower == "n")
                {
                    ShowCustomMenu();
                }
                else
                {
                    Console.WriteLine("\t\t                                        ");
                    Console.WriteLine("\t\t\t    Invalid Access,Please enter again.");
                    Console.ReadKey();
                    SearchAccount();
                }
            }
            else
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t Account Found");
                Console.WriteLine("\t\t                                                       ");
                Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
                Console.WriteLine("\t\t                 ACCOUNT DETAILS                       ");
                Console.WriteLine("\t\t ═════════════════════════════════════════════════════ ");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Account No:{0}", user.Account);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Account Balance:{0}", tempBalance);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           First Name:{0}", user.Name_F);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Last Name:{0}", user.Name_L);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Address:{0}", user.Address);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Number:{0}", tempNumber);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Email:{0}", user.Email);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t                                                       ");
                Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
                int EndCursorX = Console.CursorLeft;
                int EndCursorY = Console.CursorTop;
                Console.SetCursorPosition(EndCursorX, EndCursorY); // Good OO design and show all information from userList.
                Console.Write("\t\t\t    Check another acount (y/n)?");
                string userInput = Console.ReadLine();
                var Lower = userInput?.ToLower();
                if (Lower == "y")
                {
                    SearchAccount();
                }
                else if (Lower == "n")
                {
                    ShowCustomMenu();
                }
                else
                {
                    Console.WriteLine("\t\t                                        ");
                    Console.WriteLine("\t\t\t    Invalid Access,Please enter again.");
                    Console.ReadKey();
                    ShowCustomMenu();


                }
            }
        }
        public void Deposit()
        {
            Console.Clear();
            Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t║                      DEPOSIT                        ║");
            Console.WriteLine("\t\t║═════════════════════════════════════════════════════║");
            Console.WriteLine("\t\t║                 ENTER THE DETAILS                   ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Account Number:");
            int AcCursorX = Console.CursorLeft;
            int AcCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Amount: $");
            int AmCursorX = Console.CursorLeft;
            int AmCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
            int TempCursorX = Console.CursorLeft;
            int TempCursorY = Console.CursorTop;
            Console.SetCursorPosition(AcCursorX, AcCursorY);
            string TempAcInput = Console.ReadLine();
            long parseAcInput;
            if (!long.TryParse(TempAcInput, out parseAcInput) || parseAcInput.ToString().Length > 10)
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t\t    Please enter correct number");
                Console.ReadKey();
                Deposit();
            }
            SaveAccount(parseAcInput); // Read the information and put them all into userList
            User user = CheckUser(parseAcInput); // check if user exist first
            if (user == null)
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY); // Same y/n options 
                Console.WriteLine("\t\t\t    Account not found");
                Console.WriteLine("\t\t                             ");
                Console.Write("\t\t\t    Check another acount (y/n)?");
                string userInput = Console.ReadLine();
                var Lower = userInput?.ToLower();
                if (Lower == "y")
                {
                    Deposit();
                }
                else if (Lower == "n")
                {
                    ShowCustomMenu();
                }
                else
                {
                    Console.SetCursorPosition(TempCursorX, TempCursorY);
                    Console.WriteLine("\t\t                                                         ");
                    Console.WriteLine("\t\t\t    Invalid Access,Please enter again.");
                    Console.WriteLine("\t\t                                                         ");
                    Console.ReadKey();
                    Deposit();
                }
            }
            else
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t\t    Account Found ! Enter the amount...");
                Console.SetCursorPosition(AmCursorX, AmCursorY);
                string TempAmInput = Console.ReadLine();
                int parseAmInput;
                int oldBalance = Convert.ToInt32(tempBalance);
                if (int.TryParse(TempAmInput, out parseAmInput) && parseAmInput >= 0) // Deposit must be greater than 0.
                {
                    Console.SetCursorPosition(TempCursorX, TempCursorY);
                    Console.WriteLine("\t\t                                                                 ");
                    Console.WriteLine("\t\t\t    Deposit successful!...");
                    SaveAccount(parseAcInput); 
                    int newBalance = oldBalance + parseAmInput; //Deposit the money.
                    string text = DateTime.Now.ToString("dd-MM-yyyy") + "|" + "Deposit" + "|" + "Amount:" + parseAmInput + "|" + "Previous Balance:" + oldBalance + Environment.NewLine; // print transaction(Deposit) to account number txt.
                    String strFile = File.ReadAllText(parseAcInput + ".txt");
                    strFile = strFile.Replace(oldBalance.ToString(), newBalance.ToString()); //replace the oldBalance to newBalance.
                    File.WriteAllText(parseAcInput + ".txt", strFile);
                    File.AppendAllText(parseAcInput + ".txt", text);
                    Console.ReadKey();
                    
                }
                else
                {
                    Console.SetCursorPosition(TempCursorX, TempCursorY);
                    Console.WriteLine("\t\t\t    Invalid amount! Please try again...");
                    Console.ReadKey();
                    Deposit();
                }
            }


        }
        public void Withdraw()
        {
            Console.Clear();
            Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t║                      WITHDRAW                       ║");
            Console.WriteLine("\t\t║═════════════════════════════════════════════════════║");
            Console.WriteLine("\t\t║                 ENTER THE DETAILS                   ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Account Number:");
            int AcCursorX = Console.CursorLeft;
            int AcCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Amount: $");
            int AmCursorX = Console.CursorLeft;
            int AmCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
            int TempCursorX = Console.CursorLeft;
            int TempCursorY = Console.CursorTop;
            Console.SetCursorPosition(AcCursorX, AcCursorY);
            string TempAcInput = Console.ReadLine();
            long parseAcInput;
            if (!long.TryParse(TempAcInput, out parseAcInput) || parseAcInput.ToString().Length > 10) // check if key input is a int or less then 10 characters.
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t\t    Please enter correct number");
                Console.ReadKey();
                Deposit();
            }
            SaveAccount(parseAcInput); // Same with above
            User user = CheckUser(parseAcInput); //check if user exist.
            if (user == null)
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t\t    Account not found");
                Console.WriteLine("\t\t                             ");
                Console.Write("\t\t\t    Check another acount (y/n)?");
                string userInput = Console.ReadLine();
                var Lower = userInput?.ToLower();
                if (Lower == "y")
                {
                    Deposit();
                }
                else if (Lower == "n")
                {
                    ShowCustomMenu();
                }
                else
                {
                    Console.SetCursorPosition(TempCursorX, TempCursorY);
                    Console.WriteLine("\t\t                                                         ");
                    Console.WriteLine("\t\t\t    Invalid Access,Please enter again.");
                    Console.WriteLine("\t\t                                                         ");
                    Console.ReadKey();
                    Deposit();
                }
            }
            else
            {

                {
                    Console.SetCursorPosition(TempCursorX, TempCursorY);
                    Console.WriteLine("\t\t\t    Account Found ! Enter the amount...");
                    Console.SetCursorPosition(AmCursorX, AmCursorY);
                    string TempAmInput = Console.ReadLine();
                    int parseAmInput;
                    int oldBalance = Convert.ToInt32(tempBalance);
                    if (int.TryParse(TempAmInput, out parseAmInput) && parseAmInput <= oldBalance) //check if Withdraw amount is greater than balance
                    {
                        Console.SetCursorPosition(TempCursorX, TempCursorY);
                        Console.WriteLine("\t\t                                                                 ");
                        Console.WriteLine("\t\t\t    Withdraw successful!...");
                        SaveAccount(parseAcInput);
                        int newBalance = oldBalance - parseAmInput;
                        string text = DateTime.Now.ToString("dd-MM-yyyy") + "|" + "Withdraw" + "|" + "Amount:" + parseAmInput + "|" + "Previous Balance:" + oldBalance + Environment.NewLine; // print transaction(Withdraw) to account number txt.
                        String strFile = File.ReadAllText(parseAcInput + ".txt"); //replace the oldBalance to newBalance.
                        strFile = strFile.Replace(oldBalance.ToString(), newBalance.ToString());
                        File.WriteAllText(parseAcInput + ".txt", strFile);
                        File.AppendAllText(parseAcInput + ".txt", text);
                        Console.ReadKey();

                    }
                    else
                    {
                        Console.SetCursorPosition(TempCursorX, TempCursorY);
                        Console.WriteLine("\t\t\t    Invalid amount! Please try again...");
                        Console.ReadKey();
                        Withdraw();
                    }
                }
                
            }
        }
        public void SendEmail(long account) // It has error when send coz I didn't put my gmail account and password on the top(privacy). I will show this functions in DEMO next week.
        {
            using (MailMessage mail = new MailMessage())
            {
                mail.From = new MailAddress(emailFromAddress);  //All elements are needed to connect to Gmail server.
                mail.To.Add(emailToAddress);
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;
                mail.Attachments.Add(new Attachment(account +".txt"));// Uncomment this to send any attachment  
                using (SmtpClient smtp = new SmtpClient(smtpAddress, portNumber))
                {
                    smtp.Credentials = new NetworkCredential(emailFromAddress, password);  //Send eamil through SMTP
                    smtp.EnableSsl = enableSSL;
                    smtp.Send(mail);

                }
            }
        }
        public void AcStatment()
        {
            Console.Clear();
            Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t║                     STATEMENT                       ║");
            Console.WriteLine("\t\t║═════════════════════════════════════════════════════║");
            Console.WriteLine("\t\t║                 ENTER THE DETAILS                   ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Account Number:");
            int AcCursorX = Console.CursorLeft;
            int AcCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
            int TempCursorX = Console.CursorLeft;
            int TempCursorY = Console.CursorTop;
            Console.SetCursorPosition(AcCursorX, AcCursorY);
            string TempAcInput = Console.ReadLine();
            long parseAcInput;
            if (!long.TryParse(TempAcInput, out parseAcInput) || parseAcInput.ToString().Length > 10) // check if input is int or a digit less than 10 characters
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t                                 ");
                Console.WriteLine("\t\t\t    Please enter correct number");
                Console.ReadKey();
                SearchAccount();
            }
            SaveAccount(parseAcInput); //Same with Above, Read the information from txt file.
            User user = CheckUser(parseAcInput); // Same with Above, just for check if key input is equal with user account number.
            if (user == null)
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t                                 ");
                Console.WriteLine("\t\t\t    Account not found");
                Console.WriteLine("\t\t                                 ");
                Console.Write("\t\t\t    Check another acount (y/n)?");
                string userInput = Console.ReadLine();
                var Lower = userInput?.ToLower();
                if (Lower == "y")
                {
                    AcStatment();
                }
                else if (Lower == "n")
                {
                    ShowCustomMenu();
                }
                else
                {
                    Console.WriteLine("\t\t                                        ");
                    Console.WriteLine("\t\t\t    Invalid Access,Please enter again.");
                    Console.ReadKey();
                    AcStatment();
                }
            }
            else
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t Account Found");
                Console.WriteLine("\t\t                                                       ");
                Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
                Console.WriteLine("\t\t                 ACCOUNT DETAILS                       ");
                Console.WriteLine("\t\t ═════════════════════════════════════════════════════ ");
                Console.WriteLine("\t\t║  Account Statement                                  ║");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Account No:{0}", user.Account);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Account Balance:{0}", tempBalance);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           First Name:{0}", user.Name_F);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Last Name:{0}", user.Name_L);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Address:{0}", user.Address);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Number:{0}", tempNumber);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Email:{0}", user.Email);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t                                                       ");
                Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
                int EndCursorX = Console.CursorLeft;
                int EndCursorY = Console.CursorTop;
                Console.SetCursorPosition(EndCursorX, EndCursorY);
                Console.Write("\t\t\t    Email statement (y/n)?");
                string userInput = Console.ReadLine();
                var Lower = userInput?.ToLower();
                if (Lower == "y")
                {
                    Console.WriteLine("\t\t                             ");
                    Console.WriteLine("\t\t\t    Email sent successfully");
                    SendEmail(parseAcInput); //Send Email based on account number.
                }
                else if (Lower == "n")
                {
                    ShowCustomMenu();
                }
                else
                {
                    Console.WriteLine("\t\t                                        ");
                    Console.WriteLine("\t\t\t    Invalid Access,Please enter again.");
                    Console.ReadKey();
                    AcStatment();


                }
            }


        }
        public void DeleteAccount()
        {
            Console.Clear();
            Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
            Console.WriteLine("\t\t║                 DELETE AN ACCOUNT                   ║");
            Console.WriteLine("\t\t║═════════════════════════════════════════════════════║");
            Console.WriteLine("\t\t║                 ENTER THE DETAILS                   ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.Write("\t\t║           Account Number:");
            int AcCursorX = Console.CursorLeft;
            int AcCursorY = Console.CursorTop;
            Console.WriteLine("\t\t\t      ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t║                                                     ║");
            Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
            int TempCursorX = Console.CursorLeft;
            int TempCursorY = Console.CursorTop;
            Console.SetCursorPosition(AcCursorX, AcCursorY);
            string TempAcInput = Console.ReadLine();
            long parseAcInput;
            if (!long.TryParse(TempAcInput, out parseAcInput) || parseAcInput.ToString().Length > 10) // check if input is int or a digit less than 10 characters
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t                                 ");
                Console.WriteLine("\t\t\t    Please enter correct number");
                Console.ReadKey();
                SearchAccount();
            }
            SaveAccount(parseAcInput); // //Same with Above, Read the information from txt file.
            User user = CheckUser(parseAcInput); // Same with Above, just for check if key input is equal with user account number.
            if (user == null)
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t                                 ");
                Console.WriteLine("\t\t\t    Account not found");
                Console.WriteLine("\t\t                                 ");
                Console.Write("\t\t\t    Check another acount (y/n)?");
                string userInput = Console.ReadLine();
                var Lower = userInput?.ToLower();
                if (Lower == "y")
                {
                    DeleteAccount();
                }
                else if (Lower == "n")
                {
                    ShowCustomMenu();
                }
                else
                {
                    Console.WriteLine("\t\t                                        ");
                    Console.WriteLine("\t\t\t    Invalid Access,Please enter again.");
                    Console.ReadKey();
                    DeleteAccount();
                }
            }
            else
            {
                Console.SetCursorPosition(TempCursorX, TempCursorY);
                Console.WriteLine("\t\t Account Found");
                Console.WriteLine("\t\t                                                       ");
                Console.WriteLine("\t\t╔═════════════════════════════════════════════════════╗");
                Console.WriteLine("\t\t                 ACCOUNT DETAILS                       ");
                Console.WriteLine("\t\t ═════════════════════════════════════════════════════ ");
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Account No:{0}", user.Account);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Account Balance:{0}", tempBalance);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           First Name:{0}", user.Name_F);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Last Name:{0}", user.Name_L);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Address:{0}", user.Address);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Number:{0}", tempNumber);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t           Email:{0}", user.Email);
                Console.WriteLine("\t\t║                                                     ║");
                Console.WriteLine("\t\t                                                       ");
                Console.WriteLine("\t\t╚═════════════════════════════════════════════════════╝");
                int EndCursorX = Console.CursorLeft;
                int EndCursorY = Console.CursorTop;
                Console.SetCursorPosition(EndCursorX, EndCursorY);
                Console.Write("\t\t\t    Delete (y/n)?");
                string userInput = Console.ReadLine();
                var Lower = userInput?.ToLower();
                if (Lower == "y")
                {
                    File.Delete(parseAcInput + ".txt"); //Delete the file with typed account number
                    UserList.Clear(); // Clear all the elements in userList
                    Console.WriteLine("\t\t                         ");
                    Console.WriteLine("\t\t\t    Account Deleted!...");
                    Console.ReadKey();
                    
                }
                else if (Lower == "n")
                {
                    ShowCustomMenu();
                }
                else
                {
                    Console.WriteLine("\t\t                                        ");
                    Console.WriteLine("\t\t\t    Invalid Access,Please enter again.");
                    Console.ReadKey();
                    DeleteAccount();


                }
            }

        }
        public User CheckUser(long account) // check if user account equals to input account(key), then return the user.
        {
            foreach (var user in UserList)
            {
                if (user.Account == account)
                {
                    return user;
                }
            }
            return null;
        }


    }
}




