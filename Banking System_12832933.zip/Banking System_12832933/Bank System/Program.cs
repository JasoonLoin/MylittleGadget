﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net.Mail;

namespace BankSystem
{
    class program
    {
        static void Main(string[] args)
        {
            
            Bank bank = new Bank();
     
            bank.ShowLoginMenu(); //excute the function.
            
            
            Console.ReadKey();
          
           

        }
    }
}
