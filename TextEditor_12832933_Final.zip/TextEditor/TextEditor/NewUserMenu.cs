﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace TextEditor
{
    public partial class NewUserMenu : Form
    {
        public Dictionary<string, string> userList = new Dictionary<string, string>();  // create dictionary for collecting data
        public NewUserMenu()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filePath = "login.txt";
            List<string> lines = new List<string>();    //Create list for containing the line in txt file
            lines = File.ReadAllLines(filePath).ToList();   //make it become list

            foreach (var line in lines)
            {
                string[] token = line.Split(',');  //Split the line(delimiter)
                if (textBox1.Text == token[0]) //check if userName and password match
                {
                    MessageBox.Show("User Name or Password has been signed up,Please Try again.", "Error"); //Clear the information on gap
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    comboBox1.Text = null;
                    textBox4.Clear();
                    textBox5.Clear();
                    dateTimePicker1.Value = DateTime.Now;
                    return;
                    
                }
            }           
            if (textBox1.Text != "" && textBox2.Text != "" && textBox2.Text == textBox3.Text && comboBox1.Text == "View" && textBox4.Text != "" && textBox5.Text != "" ) //check if entered text box is empty or combobox is checked 
            {
                lines.Add(textBox1.Text + "," + textBox2.Text + "," + comboBox1.Text + "," + textBox4.Text + "," + textBox5.Text + "," + dateTimePicker1.Value.ToString("dd-MM-yyyy")); //Add all information into txt file
                File.WriteAllLines(filePath, lines);
                userList.Add(textBox1.Text, textBox2.Text);
                MessageBox.Show("New User Created,Welcome to Text Editor.", "New User Created");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                comboBox1.Text = null;
                textBox4.Clear();
                textBox5.Clear();
                dateTimePicker1.Value = DateTime.Now;
                
            }
            else if(textBox1.Text != "" && textBox2.Text != "" && textBox2.Text == textBox3.Text && comboBox1.Text == "Edit" && textBox4.Text != "" && textBox5.Text != "")//check if entered text box is empty or combobox is checked
            {
                {
                    lines.Add(textBox1.Text + "," + textBox2.Text + "," + comboBox1.Text + "," + textBox4.Text + "," + textBox5.Text + "," + dateTimePicker1.Value.ToString("dd-MM-yyyy"));//Add all information into txt file
                    File.WriteAllLines(filePath, lines);
                    userList.Add(textBox1.Text, textBox2.Text);
                    MessageBox.Show("New User Created,Welcome to Text Editor.", "New User Created");
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    comboBox1.Text = null;
                    textBox4.Clear();
                    textBox5.Clear();
                    dateTimePicker1.Value = DateTime.Now;
                }
            }
            else if (textBox2.Text != textBox3.Text)//check if two password fields match
            {
                MessageBox.Show("Two password fields didn't match,please try again.");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                comboBox1.Text = null;
                textBox4.Clear();
                textBox5.Clear();
                dateTimePicker1.Value = DateTime.Now;
            }
            else
            {
                MessageBox.Show("Invalid Enter,Please Try again.", "Error"); //check if input is correct 
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                comboBox1.Text = null;
                textBox4.Clear();
                textBox5.Clear();
                dateTimePicker1.Value = DateTime.Now;
            }
           
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            LoginMenu f1 = new LoginMenu();   //Move to loginMenu
            f1.ShowDialog();
            
            
            
        }

        private void NewUserMenu_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void NewUserMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();  //Exit the program
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
