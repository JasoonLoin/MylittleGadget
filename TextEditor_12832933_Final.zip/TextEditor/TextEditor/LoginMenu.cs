﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace TextEditor
{
    public partial class LoginMenu : Form
    {
        public bool isAccess = true;
        
        public LoginMenu()
        {
            InitializeComponent();
            
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)// View and Edit Mode is activated
        {

            string filePath = "login.txt";
            List<string> lines = File.ReadAllLines(filePath).ToList(); 
            foreach (var line in lines)
            {
                string[] token = line.Split(',');
                if (textBox1.Text == token[0] && textBox2.Text == token[1])
                {
                    MessageBox.Show("Login Success,Welcome to the Text Editor.", "Login");
                    this.Hide();
                    if (token[2] == "View")
                    {

                        isAccess = false;
                        TextEditor ad = new TextEditor(textBox1.Text, isAccess);
                        ad.ShowDialog();
                        this.Close();
                        

                    }
                    else
                    {

                        isAccess = true;
                        TextEditor ad = new TextEditor(textBox1.Text, isAccess);
                        ad.ShowDialog();
                        this.Close();
                    }
                }

            }
            MessageBox.Show("Incorrect User name or Password,Please try again", "Error");
            textBox1.Clear();
            textBox2.Clear();


        }

        private void New_Click(object sender, EventArgs e)
        {
            this.Hide();
            NewUserMenu f2 = new NewUserMenu();    //Move to NewUserMenu Window
            f2.ShowDialog();



        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginMenu_Load(object sender, EventArgs e)
        {

        }

        private void LoginMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
