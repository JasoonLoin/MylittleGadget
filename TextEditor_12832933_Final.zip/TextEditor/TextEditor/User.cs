﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TextEditor
{
    class User//All Variables for UserList
    {
        public User(string username,string password,string user_Type,string last_Name,string first_Name,string dob)
        {
            this.username = username;
            this.password = password;
            this.user_Type = user_Type;
            this.last_Name = last_Name;
            this.first_Name = first_Name;
            this.dob = dob;
        }
        private string username;
        public string Username
        {
            get { return Username; }
            set { Username = value; }
        }
        private string password;
        public string Password
        {
            get { return Password;}
            set { Password = value;}
        }
        private string user_Type;
        public string User_Type
        {
            get { return User_Type; }
            set { User_Type = value; }
        }
        private string last_Name;
        public string Last_Name
        {
            get { return Last_Name; }
            set { Last_Name = value; }
        }
        private string first_Name;
        public string First_Name
        {
            get { return First_Name; }
            set { First_Name = value; }
        }
        private string dob;
        public string Dob
        {
            get { return Dob;}
            set { Dob = value;}
        }
    }
}
