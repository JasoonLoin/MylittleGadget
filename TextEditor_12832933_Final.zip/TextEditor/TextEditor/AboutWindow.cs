﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TextEditor
{
    public partial class AboutWindow : Form
    {
        bool isVisible = false;    //Make About Window visiable or invisiable
        string UserName;
        bool isAccess;
        public AboutWindow(string UserName, bool isAccess)
        {
            InitializeComponent();
            this.UserName = UserName;     //Some variables for remembering the user information
            this.isAccess = isAccess;
            textBox1.Multiline = true;
            textBox1.ScrollBars = ScrollBars.Both;
            textBox1.Text = "Amazing Text Editor" + Environment.NewLine + "Version:1.1"   //introduction information for Text Editor
            + Environment.NewLine + "The Amazing Text Editor is your useful tool to edit the text.The Amazing Text Editor and its user interface are protectd by trademark and other pending or existing intellectual property rights in All countries/regions.";
            textBox1.Select(textBox1.Text.Length, 0);
            
           
           

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (isVisible == false)     //Make About Window visiable or invisiable
            {
                textBox1.ForeColor = this.BackColor;
                isVisible = true;
            }
            else
            {
                textBox1.ForeColor = this.ForeColor;
                isVisible = false;
            }
           
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginMenu lm = new LoginMenu();
            TextEditor td = new TextEditor(UserName,isAccess);   //Change window to text editor
            td.ShowDialog();
            td.Close();
            
        }

        private void AboutWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();    //Exit the program
        }
    }
}
