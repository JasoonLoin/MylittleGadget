﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace TextEditor
{

    public partial class TextEditor : Form
    {
        string path = ""; //Some Variables for Edit and View mode
        private bool isAccess;
        public TextEditor(string UserName,bool isAccess)
        {

            InitializeComponent();
            toolStripLabel1.Text = UserName;//Get User Name variable
            this.isAccess = isAccess;
            
        }

        private void Add()// Add A new Page
        {
            richTextBox1.Clear();    
            path = "";
            this.Text = "new File*";
            this.richTextBox1.ContextMenuStrip = contextMenuStrip1;
            this.richTextBox1.Dock = DockStyle.Fill;
           
            
        }
        private void Save()//Save the file
        {

            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            saveFileDialog1.Title = "Save";
            saveFileDialog1.Filter = "RTF|*.rtf|Text Files|*.txt|VB Files|*.vb|C# Files|*.cs|All Files|*.*"; 
            if (path == string.Empty)
            {
                DialogResult saveResult = saveFileDialog1.ShowDialog();
                if (saveResult == DialogResult.OK)
                {
                    path = saveFileDialog1.FileName;
                    try
                    {
                        richTextBox1.SaveFile(path, RichTextBoxStreamType.RichText);
                    }
                    catch (IOException ioe)
                    {
                        MessageBox.Show("Error saving file:" + ioe.Message); //Try Save the file if error give error information
                    }
                }
                
            }
            else
            {
                richTextBox1.SaveFile(path, RichTextBoxStreamType.RichText); //Auto Save the file
            }

        }

        private void SaveAs()//Save as File
        {
            saveFileDialog1.Title = "Save As";
            DialogResult saveResult = saveFileDialog1.ShowDialog();
            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            saveFileDialog1.Filter = "RTF|*.rtf|Text Files|*.txt|VB Files|*.vb|C# Files|*.cs|All Files|*.*";
            if (saveResult == DialogResult.OK)
            {
                path = saveFileDialog1.FileName;
                try
                {
                    richTextBox1.SaveFile(path, RichTextBoxStreamType.RichText);
                }
                catch (IOException ioe)
                {
                    MessageBox.Show("Error saving file:" + ioe.Message);
                }
            }
        }
        private void Open()//Open the file
        {
            openFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            openFileDialog1.Filter = "RTF|*.rtf|Text Files|*.txt|VB Files|*.vb|C# Files|*.cs|All Files|*.*";

            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                path = openFileDialog1.FileName;
                if (openFileDialog1.FileName.Length > 0)
                {
                   richTextBox1.LoadFile(path, RichTextBoxStreamType.RichText);  //LoadFile Method to open the file
                   this.Text = Path.GetFileName(path);
                }
            }

        }
        private void Undo() //Undo the file
        {
            richTextBox1.Undo();
        }

        private void Redo() //Redo the file
        {
            richTextBox1.Redo();
        }

        private void Cut() //Cut the file
        {
            richTextBox1.Cut();
        }

        private void Copy() //Copy the file
        {
            richTextBox1.Copy();
        }

        private void Paste() //Paste the file
        {
            richTextBox1.Paste();
        }

        private void SelectAll()//Select all file
        {
            richTextBox1.SelectAll();
        }
        private void GetFontCollection()//Get the Font Collection
        {
            InstalledFontCollection InsFonts = new InstalledFontCollection();

            foreach (FontFamily item in InsFonts.Families)
            {
                toolStripComboBox1.Items.Add(item.Name);
            }
            toolStripComboBox1.SelectedIndex= 2;
        }

        private void PopulateFontSizes()//Get the Font Size
        {
            for (int i = 8; i <= 20; i++)
            {
                toolStripComboBox2.Items.Add(i);
            }

            toolStripComboBox2.SelectedIndex = 8;
        }
   

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Open();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveAs();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e) //Move to the loginMenu
        {
            this.Hide();
            LoginMenu f1 = new LoginMenu();
            f1.ShowDialog();
            this.Close();

        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Undo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Redo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cut();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Copy();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Paste();
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SelectAll();
        }
       
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            SaveAs();
        }
        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)// When selected text changes,the font change
        {
            if (toolStripComboBox1.SelectedItem.ToString() != null)
            {
                if (richTextBox1.SelectionFont != null)
                {
                    Font NewFont = new Font(toolStripComboBox1.SelectedItem.ToString(), richTextBox1.SelectionFont.Size, richTextBox1.SelectionFont.Style);

                    richTextBox1.SelectionFont = NewFont;
                }
                else
                {
                    float NewSize;
                    float.TryParse(toolStripComboBox2.SelectedItem.ToString(), out NewSize);
                    richTextBox1.SelectionFont = this.richTextBox1.Font;

                    Font NewFont = new Font(toolStripComboBox1.SelectedItem.ToString(), NewSize, richTextBox1.Font.Style); //check if selectionfont is null
                    richTextBox1.SelectionFont = NewFont;
                }
            }
        }
        private void toolStripComboBox2_SelectedIndexChanged(object sender, EventArgs e)//change the font size when click the combobox
        {
            float NewSize;

            float.TryParse(toolStripComboBox2.SelectedItem.ToString(), out NewSize);

            Font NewFont = new Font(richTextBox1.SelectionFont.Name, NewSize, richTextBox1.SelectionFont.Style);

            richTextBox1.SelectionFont = NewFont; //Newsize is allocated
        }
        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            Add();
        }
        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            Open();
        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void cutToolStripButton_Click(object sender, EventArgs e)
        {
            Cut();
        }

        private void copyToolStripButton_Click(object sender, EventArgs e)
        {
            Copy();
        }

        private void pasteToolStripButton_Click(object sender, EventArgs e)
        {
            Paste();
        }
        private void undoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Undo();
        }

        private void redoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Redo();
        }

        private void cutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Cut();
        }

        private void copyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Copy();
        }

        private void pasteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Paste();
        }
        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripSeparator6_Click(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }
        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
        private void aboutToolStripMenuItem_Click_1(object sender, EventArgs e)//Move to the About Window
        {
            this.Hide();
            AboutWindow f3 = new AboutWindow(toolStripLabel1.Text, isAccess);
            f3.ShowDialog();
            this.Close();
            
        }
        private void toolStripButton2_Click_1(object sender, EventArgs e)//Bold function to set the font
        {
            if (richTextBox1.SelectionFont != null)
            {
                Font BoldFont = new Font(richTextBox1.SelectionFont.FontFamily, richTextBox1.SelectionFont.SizeInPoints, FontStyle.Bold);
                Font RegularFont = new Font(richTextBox1.SelectionFont.FontFamily, richTextBox1.SelectionFont.SizeInPoints, FontStyle.Regular);


                if (richTextBox1.SelectionFont.Bold)
                {
                    richTextBox1.SelectionFont = RegularFont; //change it back to Regular function
                   
                }
                else
                {
                    richTextBox1.SelectionFont = BoldFont;//change it back to Bold function
                   
                }
            }
            else 
            {
                richTextBox1.SelectionFont = this.richTextBox1.Font;
                float NewSize;
                float.TryParse(toolStripComboBox2.SelectedItem.ToString(), out NewSize);
                Font BoldFont = new Font(richTextBox1.SelectionFont.FontFamily, NewSize, FontStyle.Bold);
                Font RegularFont = new Font(richTextBox1.SelectionFont.FontFamily, NewSize, FontStyle.Regular);
            }
        }

        private void toolStripButton3_Click_1(object sender, EventArgs e)//Change it to Italic Font
        {
            if (richTextBox1.SelectionFont != null)
            {
                Font ItalicFont = new Font(richTextBox1.SelectionFont.FontFamily, richTextBox1.SelectionFont.SizeInPoints, FontStyle.Italic);
                Font RegularFont = new Font(richTextBox1.SelectionFont.FontFamily, richTextBox1.SelectionFont.SizeInPoints, FontStyle.Regular);


                if (richTextBox1.SelectionFont.Italic)
                {
                    richTextBox1.SelectionFont = RegularFont;
                    
                }
                else
                {
                    richTextBox1.SelectionFont = ItalicFont;
                   
                }
            }
            else
            {
                richTextBox1.SelectionFont = this.richTextBox1.Font;
                float NewSize;
                float.TryParse(toolStripComboBox2.SelectedItem.ToString(), out NewSize);
                Font ItalicFont = new Font(richTextBox1.SelectionFont.FontFamily, NewSize, FontStyle.Italic);
                Font RegularFont = new Font(richTextBox1.SelectionFont.FontFamily, NewSize, FontStyle.Regular);
            }
        }

        private void toolStripButton4_Click_1(object sender, EventArgs e)//Underline function for words
        {
            if (richTextBox1.SelectionFont != null)
            {
                Font UnderlineFont = new Font(richTextBox1.SelectionFont.FontFamily, richTextBox1.SelectionFont.SizeInPoints, FontStyle.Underline);
                Font RegularFont = new Font(richTextBox1.SelectionFont.FontFamily, richTextBox1.SelectionFont.SizeInPoints, FontStyle.Regular);

                if (richTextBox1.SelectionFont.Underline)
                {
                    richTextBox1.SelectionFont = RegularFont; //Change it back to RegularFont

                }
                else
                {
                    richTextBox1.SelectionFont = UnderlineFont;

                }
            }
            else
            {
                richTextBox1.SelectionFont = this.richTextBox1.Font;
                float NewSize;
                float.TryParse(toolStripComboBox2.SelectedItem.ToString(), out NewSize);
                Font UnderlineFont = new Font(richTextBox1.SelectionFont.FontFamily, NewSize, FontStyle.Underline);
                Font RegularFont = new Font(richTextBox1.SelectionFont.FontFamily, NewSize, FontStyle.Regular);

            }
        }
        private void toolStripComboBox2_Click(object sender, EventArgs e)
        {

        }
        private void toolStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void TextEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); //Exit
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void TextEditor_Load(object sender, EventArgs e)
        {
            if (isAccess == false)
            {
                richTextBox1.ReadOnly = true;
                richTextBox1.Enabled = false;
                editToolStripMenuItem.Enabled = false;
                newToolStripMenuItem.Enabled = false;
                saveToolStripMenuItem.Enabled = false;
                saveAsToolStripMenuItem.Enabled = false;
                newToolStripButton.Enabled = false;
                saveToolStripButton.Enabled = false;
                toolStripButton1.Enabled = false;
                toolStripButton2.Enabled = false;
                toolStripButton3.Enabled = false;
                toolStripButton4.Enabled = false;
                toolStripComboBox1.Enabled = false;
                toolStripComboBox2.Enabled = false;
                toolStrip2.Enabled = false;

            }
            GetFontCollection(); //GetFontCollection function awaken
            PopulateFontSizes(); //Font Size function awaken
        }
    }
}
